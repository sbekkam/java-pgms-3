package com.cg.payroll.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;

public class UpdateController {
	@Autowired
	PayrollServices payrollServices;
	public String updateUserUser(@ModelAttribute("associate")Associate associate) throws AssociateDetailsNotFoundException{
		return null;
	}
}
