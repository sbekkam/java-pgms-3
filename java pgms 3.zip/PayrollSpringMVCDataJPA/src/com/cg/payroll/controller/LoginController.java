package com.cg.payroll.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;

public class LoginController {
	@Autowired
	PayrollServices payrollServices;
	
	@RequestMapping(value="/authUser")
	public String authUser(@Valid@ModelAttribute("associate")Associate associate, BindingResult result){
			try {
				if(associate.getPassword().equals(payrollServices.getAssociateDetails(associate.getAssociateID()).getPassword())){
					return "successPage";
				}
				return "errorPage";
			} catch (Exception e) {
				 return "errorPage";
			}
			
		

	}

}
