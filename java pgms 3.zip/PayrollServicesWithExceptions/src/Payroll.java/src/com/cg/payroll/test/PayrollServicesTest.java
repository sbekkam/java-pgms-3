package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;



import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollServicesTest {

	private static PayrollServices payrollservices;
	@BeforeClass
	public static void setUpTestEnv(){
		payrollservices=new PayrollServicesImpl();
	
	}
	//private int associateId;
	@Before 
	public  void setUpMockData(){
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 12000, "sushu", "bakki", "eee", "analyst", "FYT566", "sushu.com", new Salary(230000, 10000, 19000), new BankDetails(1234, "xyz", "FYTGH256365"));
		Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 40000, "mani", "pichi", "ece", "analyst", "FYT56667", "mani.com", new Salary(50000, 1000, 1000), new BankDetails(12345, "asd", "FYTGH223265"));
		Associate associate3=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 14000, "sam", "buchi", "eie", "analyst", "FYT56643", "sam.com", new Salary(250000, 1000, 149000), new BankDetails(12346, "qwe", "HJKKTGH256365"));

		PayrollDAOServicesImpl.associates.put(associate1.getAssociateID(), associate1);
		PayrollDAOServicesImpl.associates.put(associate2.getAssociateID(), associate2);
		PayrollDAOServicesImpl.associates.put(associate3.getAssociateID(), associate3);
		
	}
	@Test
	public void validAssociateDetails() throws  AssociateDetailsNotFoundException
{
		Associate expectedassociate=payrollservices.getAssociateDetails(112);
		Associate actualassociate=new Associate(112, 40000, "mani", "pichi", "ece", "analyst", "FYT56667", "mani.com", new Salary(50000, 1000, 1000), new BankDetails(12345, "asd", "FYTGH223265"));
		assertEquals(expectedassociate, actualassociate);
	}

	@Test(expected=AssociateDetailsNotFoundException.class)
	public void inValidAssociateDetails() throws  AssociateDetailsNotFoundException
{
		Associate expectedassociate=payrollservices.getAssociateDetails(1147);
		Associate actualassociate=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 13000, "sam", "pichi", "ece", "analyst", "FYT56667", "sam.com", new Salary(240000, 10404, 23000), new BankDetails(12345, "asd", "FYTGH223265"));
		assertEquals(expectedassociate, actualassociate);
	}

@Test 
public void netsalary() throws AssociateDetailsNotFoundException,PayrollServicesDownException{
		

	
//	Associate expectedsal=
	//Associate actualsal=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 13000, "sam", "pichi", "ece", "analyst", "FYT56667", "sam.com", new Salary(240000, 10404, 23000), new BankDetails(12345, "asd", "FYTGH223265"));
	assertEquals(78566, payrollservices.calculateNetSalary(112), 664);
	//Assert.assertEquals(78566.664, payrollservices.calculateNetSalary(112));

}
	@After
	public  void tearDownMockData(){
		PayrollDAOServicesImpl.associates.remove(PayrollUtility.ASSOCIATE_ID_COUNTER++);
		
	}
	@AfterClass
	public static void tearDownTestEnv(){
		payrollservices=null;
	
	}
}