package com.cg.project.beans;

public class Associate {
	private int associateId;
	private String firstName,LastName;
	private Address address;
	
public Associate() {
	
}
		
	public Associate(int associateId, String firstName, String lastName, Address address) {
		super();
		this.associateId = associateId;
		this.firstName = firstName;
		LastName = lastName;
		this.address = address;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", firstName=" + firstName + ", LastName=" + LastName
				+ ", address=" + address + "]";
	}

}
