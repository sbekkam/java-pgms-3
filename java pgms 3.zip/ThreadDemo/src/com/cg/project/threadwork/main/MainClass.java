package com.cg.project.threadwork.main;

import com.cg.project.threadwork.MyThread;

public class MainClass {
	public static void main(String[] args) {
		MyThread resource = new MyThread();
		Thread th1 = new Thread(resource, "thread-1");
		Thread th2 = new Thread(resource, "thread-2");
		th1.start();
		th2.start();
		
	}

	/*public static void main(String[] args) {
		MyThread th1 = new MyThread("thread-1");
		th1.start();
		MyThread th2 = new MyThread("thread-2");
		th2.start();*/
		

	}


