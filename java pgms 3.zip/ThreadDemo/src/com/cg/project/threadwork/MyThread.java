package com.cg.project.threadwork;

public class MyThread extends Thread{

	public MyThread() {
		super();

	}

	public MyThread(String name) {
		super(name);

	}
	@Override
	public void run(){
		Thread t = Thread.currentThread();
		if(t.getName().equals("thread-1"))
			for (int i = 0; i < 100; i++) {
				if (i % 2 == 0) 
					System.out.println(i+" is even number " );
				//System.out.print("even numbers");

			}
		else  if(t.getName().equals("thread-2"))
			for (int j = 0; j < 100; j++) {
				if(j%2!=0)
					System.out.println(j +" is odd number ");
				//System.out.print("odd numbers");





			}




	}
}




