package com.cg.project.test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.LoginPage;

public class LoginPageTest {
	public static WebDriver driver;
	private LoginPage loginPage;
	
	@BeforeClass
	public static void setUpBeforeClass()  {
		System.setProperty("webdriver.chrome.driver", "D:\\SELENIUM 2\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	
	@Before
	public void setUpTestEnv() {
		driver.get("https://github.com/login");
		loginPage = new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}


	@Test
	public void testForBlankUserNameAndPassword() {
		loginPage.setUsername("");
		loginPage.setPassword("");
		loginPage.ClickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}

@Test
	public void testForValidUserNameAndInvalidPassword() {
		loginPage.setUsername("sbekkam");
		loginPage.setPassword("");
		loginPage.ClickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	
	@Test
	public void testForInvalidUserNameAndValidPassword() {
		loginPage.setUsername("sushmabekkam");
		loginPage.setPassword("sushu@4b");
		loginPage.ClickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidUserNameAndValidPassword() {
		loginPage.setUsername("sbekkam");
		loginPage.setPassword("sushu@4b");
		loginPage.ClickSubmitButton();	
		
		String actualMessage=driver.findElement(By.xpath("//meta[@name='user-login']" )).getAttribute("content");
		System.out.println("Message:-"+actualMessage);
		String expectedMessage="sbekkam";
		Assert.assertEquals(expectedMessage, actualMessage);
	}
	@AfterClass
	public static void tearDownAfterClass()  {
		driver.close();
		driver= null;
	}
	@After
	public void tearDown(){
		loginPage=null;
		
	}
}
