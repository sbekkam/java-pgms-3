package com.cg.project.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.LoginPage;
import com.cg.project.RegistrationPage;

public class RegistrationPageTest {
	
	public static WebDriver driver;
	private RegistrationPage registrationPage;
	
	//private LoginPage loginPage;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\SELENIUM 2\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@AfterClass
	public static void tearDownAfterClass()  {
	}

	@Before
	public void setUpTestEnv() {
		driver.get("https://github.com/join");
		registrationPage = new RegistrationPage();
		PageFactory.initElements(driver, registrationPage);
		}
	
	
	@Test
	public void testForBlankUserNameAndEmailAndPassword() {
		registrationPage.setUsername("");
		registrationPage.setEmail("");
		registrationPage.setPassword("");
		registrationPage.ClickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//*[@id=\"signup-form\"]/div")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
		
	}
	@Test
	public void testForInvalidUserNameAndPasswordAndEmail(){
		registrationPage.setUsername("sushma");
		registrationPage.setPassword("sushu");
		registrationPage.setEmail("sushmabekkam");
		registrationPage.ClickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//*[@id=\"signup-form\"]/div")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Username is already taken,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
		}

	@Test
	public void testForInvalidPassword(){
		registrationPage.setUsername("bekkamsushma");
		registrationPage.setPassword("sushu");
		registrationPage.setEmail("sushmabekkam12@gmail.com");
		registrationPage.ClickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//*[@id=\"signup-form\"]/div")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
		
	}
	@Test
	public void testForValidUserNameAndPassword(){
		registrationPage.setUsername("bekkamsushma");
		registrationPage.setPassword("sushu@4b");
		registrationPage.setEmail("sushmabekkam12@gmail.com");
		registrationPage.ClickSubmitButton();
	}
	
	
	@After
	public void tearDown()  {
	}

	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/

}
