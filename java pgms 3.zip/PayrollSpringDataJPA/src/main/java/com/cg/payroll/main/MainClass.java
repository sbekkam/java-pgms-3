package com.cg.payroll.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidDataException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
public class MainClass {
	public static void main(String args[]) throws PayrollServicesDownException, InvalidDataException, AssociateDetailsNotFoundException{
	 ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices= (PayrollServices) applicationContext.getBean("payrollServices");
		int associateId1= payrollServices.acceptAssociate(150000, "usha", "bekkam", "java", "analyst", "1234abcd", "abc@gmail.com", 50000, 1000, 1000, 12345678, "icici","icic1234");
		int associateId2= payrollServices.acceptAssociate(150000, "sushma", "bekkam", "java", "analyst", "1234abcd", "abc@gmail.com", 50000, 1000, 1000, 12345678, "icici","icic1234"); 
	/*	int associateId2= payrollServices.acceptAssociate(150000, "sravani", "bollineni", "java", "analyst", "1234abcd", "abc@gmail.com", 70000, 1000, 1000, 12345678, "icici","icic1234"); 
		payrollServices.doDeleteAssociate(associateId2);
		System.out.println(payrollServices.getAllAssociateDetails());
		payrollServices.calculateNetSalary(associateId1);
		System.out.println(payrollServices.getAssociateDetails(associateId));
		System.out.println(payrollServices.getAllAssociateDetails());
		System.out.println(payrollServices.doDeleteAssociate(associateId));
				System.out.println("connection opened");
				
		 System.out.println(payrollServices.getAssociateDetails(associateId));*/
		payrollServices.calculateNetSalary(associateId1);
		payrollServices.calculateNetSalary(associateId2);
		
		
	}
}
