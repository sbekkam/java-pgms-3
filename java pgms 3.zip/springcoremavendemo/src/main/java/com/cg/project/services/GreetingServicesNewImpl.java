package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesNewImpl  implements GreetingServices{
	@Override
	public void SayHello(String PersonName) {
		System.out.println("Hello to  " + PersonName);
		
	}

	@Override
	public void SayGoodBye(String PersonName) {
		System.out.println("Good Bye to " +  PersonName);
		
	}
}
