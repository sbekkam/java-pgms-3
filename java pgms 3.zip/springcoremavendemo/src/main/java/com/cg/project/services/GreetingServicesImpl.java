package com.cg.project.services;

public class GreetingServicesImpl implements GreetingServices{

	@Override
	public void SayHello(String PersonName) {
		System.out.println("Hello " + PersonName);
		
	}

	@Override
	public void SayGoodBye(String PersonName) {
		System.out.println("Good Bye " +  PersonName);
		
	}

}
