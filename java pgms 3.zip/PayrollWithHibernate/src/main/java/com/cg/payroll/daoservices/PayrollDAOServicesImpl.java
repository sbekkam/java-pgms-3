package com.cg.payroll.daoservices;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.SQLException;
import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.PayrollServicesDownException;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {

	@Autowired
	private SessionFactory sessionFactory;


	public PayrollDAOServicesImpl() throws PayrollServicesDownException {	
	
	}

	@Override
	public int insertAssociate(Associate associate) {
		Session session=  sessionFactory.openSession();
		Integer associateId =	(Integer) sessionFactory.openSession().save(associate);
		Transaction tx = session.beginTransaction();
		try {
		
			tx.commit();
			return associateId;
			
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
			throw e;
		}
		finally {
			session.close();
		}
		 
		//return (int) sessionFactory.openSession().save(associate);
	} 

	@Override
	public boolean updateAssociate(Associate associate)  {
		
		 sessionFactory.openSession().update(associate);
		return true;
	}
	


	@Override
	public boolean deleteAssociate(int associateId) {
		
		sessionFactory.openSession().delete(getAssociate(associateId));
		return false;
	}


	@Override
	public Associate getAssociate(int associateId) {
	
		return (Associate) sessionFactory.openSession().get(Associate.class, associateId);
	}


	@Override
	public List<Associate> getAssociates() {
		Session session = sessionFactory.openSession();
		Query query = (Query) session.createQuery("from Associate ");
		return query.list();
	}


}