package com.cg.threadingsynchronisationdemo.beans;



public class Account {
	private static int SUCCESS,FAIL=0;
	private volatile int balance;
	public Account(){}
	public Account(int balance) {
		super();
		this.balance = balance;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}

	public synchronized int deposit(int amount) {
		balance=balance+amount;
		this.notify();
	//	this.notifyAll();
		return balance;
	}
	public synchronized int withdraw(int amount) throws InterruptedException{
		if(amount<0||(getBalance()-amount)<0){
			System.out.println("\n\t\tWithdraw Fail "+ FAIL++);
			this.wait(5000);
			return balance;
		}
		else{
			balance=balance-amount;
			System.out.println("\n\t\tWithdraw Success "+ SUCCESS++);
			this.wait(5000);
			return balance;
		}

	}
}

/* public synchronized int withdraw(int amount) throws InterruptedException{
		if(balance<0||(getBalance()-amount)<0){
			System.out.println("\n\t\tWithdraw Fail "+ FAIL);
			this.wait(5000);
			return balance;
		}
		else{
			balance=balance-amount;
			System.out.println("\n\t\tWithdraw Success "+ SUCCESS);
			this.wait(5000);
			return balance;
		}*/


