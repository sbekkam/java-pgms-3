package com.cg.threadingsynchronisationdemo.beans;

public class Customer implements Runnable {
	public Customer() {}
	private static Account account;
	static{
		account= new Account(100000);
		System.out.println("Initial Balance  :"+ account.getBalance() +
				"\n\n======================");

	}


	@Override
	public void run() {
		Thread customerThread= Thread.currentThread();
		if(customerThread.getName().equals("Sam"))
			for(int i=1;i<10 ; i++){
				try {
					Thread.sleep(0);
					System.out.println("\n Sam has called deposit()" +i+ "time balance:" + account.deposit(1000));
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
	
		else if(customerThread.getName().equals("Shyam"))
		for(int i=1;i<10 ; i++){
			try {
				Thread.sleep(0);
				System.out.println("\n Shyam has called withdraw() " + i + "time balance:" + account.withdraw(3000));
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		else if(customerThread.getName().equals("Ram"))
			for (int i = 0; i < 3; i++) {
				try {
					Thread.sleep(0);
					System.out.println("\n Ram has called balance() "+i  +"time balance :" + account.getBalance());
				} catch (InterruptedException e) {

					e.printStackTrace();
				}
			}
	
			


	}
}
	

