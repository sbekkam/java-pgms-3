package Static.beans;

public class Temp {
	private static int X;
	private int a,b;
	public Temp(int a, int b) {
		super();
		this.a = a;
		this.b = b;
		X++;
	}
	public static int getX() {
		return X;
	}
	public static void setX(int x) {
		X = x;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	

	

}
