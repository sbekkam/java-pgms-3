package Static.main;

import Static.beans.Temp;

public class MainClass {

	public static void main(String[] args) {
		System.out.println(Temp.getX());
	
		
		Temp t1=new Temp(10, 20);
		System.out.	println(t1.getX());
		Temp t2=new Temp(11, 22);
		System.out.println(t1.getX());
	}

}
