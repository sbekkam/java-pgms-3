package com.cg.project.servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.benas.UserBean;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public LoginServlet() {
		super();

	}


	public void init(ServletConfig config) throws ServletException {

	}

	public void destroy() {

	}


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//	PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher;
		String userName = request.getParameter("userName");
		String password = 	request.getParameter("password");
		UserBean userBean = new UserBean(userName, password);

		if(userBean.getUserName().equals("sushma")&&userBean.getPassword().equals("bekkam")){
			dispatcher =request.getRequestDispatcher("SuccessServlet");
			request.setAttribute("userBean", userBean);
			dispatcher.forward(request, response);
		}
		else{
			dispatcher =request.getRequestDispatcher("ErrorServlet");
			request.setAttribute("error message","Invalid userId or paassword");
			dispatcher.forward(request, response);
		}

		/*if(userName.equals("sushma")&&password.equals("bekkam")){
			out.println("<font color = 'Green' size = 10> userName + password" );
		}
		else
			out.println("<font color = 'red' size = 5>username and password did not match");


		out.println("userName is "  + userName + " password  is " + password);*/



	}

}
