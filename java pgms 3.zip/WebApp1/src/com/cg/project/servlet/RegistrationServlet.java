package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public RegistrationServlet() {
		super();

	}


	public void init(ServletConfig config) throws ServletException {


	}
	public void destroy() {

	}


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String FirstName = request.getParameter("firstName");
		String LastName = request.getParameter("lastName");
		String emailId = request.getParameter("emailId");
		String MobileNo = request.getParameter("mobileNo");
		String UserName= request.getParameter("userName");
		String Password = request.getParameter("password");
		String  repswd = request.getParameter("re-password");
		String[]Communication=request.getParameterValues("communication");
		String gender=request.getParameter("gender");
		String education=request.getParameter("education");
		String Message = request.getParameter("message");

		
	//	out.println("FirstName is " + FirstName);
		//out.println("LastName is " + LastName );
		out.println("<html>");
		out.println("<head>");
		out.println("<body>");
		out.println("<div align='center' >");
		out.println("<font color='olive' size=100>Registration Page from Registration Servlet");
		out.println("<br>");		
		out.println("Welcome");
		out.println("<font color='olive' size=100>");
		out.println("<br>");
		out.println("First name is "+FirstName);
		out.println("<br>");
		out.println("last name is "+LastName);
		out.println("<br>");
		out.println("emailId is "+emailId);
		out.println("<br>");
		out.println("Mobile No is "+MobileNo);		
		out.println("<br>");
		out.println("Username is "+UserName);
		out.println("<br>");
		out.println("Password is "+Password);		
		out.println("<br>");
		out.println("your gender is "+gender);
		out.println("<br>");
		out.println("Graduation is "+education);
		out.println("<br>");
		out.println("Message is "+ Message);
		out.println("<br>");
		out.println("communication is "+Communication);
		out.println("<br>");
		for (String string : Communication) {
			out.println("\n"+string);	
		}
		out.println("</font>");
		out.println("</div>");

		out.println("</body>");

		out.println("</head>");

		out.println("</html>");
		
		
		
 		
		
		}

}
