package com.cg.Payroll.main;
//import java.util.Scanner;

import com.cg.Payroll.beans.Associate;
import com.cg.Payroll.exceptions.AssociatedetailsNotFoundException;
import com.cg.Payroll.services.PayrollServices;
import com.cg.Payroll.services.PayrollServicesImp;
public class MainClass2 {
	public static void main(String[] args) throws AssociatedetailsNotFoundException {
		try {
			PayrollServices payrollServices = new PayrollServicesImp();
			int newId1=payrollServices.acceptAssociateDetails("sushma", "bekkam", "abc@gmail.com", "java", "analyst", "abcd1234", 150000,30000,1000,1000, 212, "icici", "ifscCode") ;
			Associate a1=payrollServices.getAssociateDetails(newId1);
			float b=payrollServices.calculateNetSalary(newId1);
			System.out.println(newId1+ " " +a1.getFirstName() +" "+ "Monthly Tax:" + a1.getSalary().getMonthlyTax()+" "+a1.getSalary().getConveyenceAllowance());
			System.out.println("net Salary :" + b);	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
