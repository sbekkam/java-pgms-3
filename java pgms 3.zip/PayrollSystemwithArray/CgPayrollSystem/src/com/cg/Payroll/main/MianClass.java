package com.cg.Payroll.main;

import com.cg.Payroll.beans.Associate;

public class MianClass {

	public static void main(String[] args) {
		//Associate associate = new Associate(1234, 150000, "SUSHMA", "Bekkam", "java", "analyst", "abcdefgh", "abcd@gmail.com");
		//System.out.println(associate.getFirstName()+" "+ associate.getDesignation());
	}

}
