package com.cg.Payroll.main;

import com.cg.Payroll.beans.Associate;

public class MainClass1 {
	public static void main(String[] args) {
		int associateIdToBeSearch=1236;
		Associate associate = searchAssociate(associateIdToBeSearch);
		if(associate!=null)
			System.out.println(associate.getFirstName()+" "+ associate.getDesignation());
		else
			System.out.println("associate deals with Id "+ associateIdToBeSearch+ " not found");
	}
	public static Associate searchAssociate(int associateId){
		Associate []associates = new Associate[2];
		// associates[0] = new Associate(1234, 150000, "SUSHMA", "Bekkam", "java", "analyst", "abcdefgh", "abcd@gmail.com");
		 //associates[1] = new Associate(1236, 15000, "veena", "yeshala", "mainframe", "software", "efgh5678", "efgh@gmail.com");
		 for(Associate associate:associates){
			 if(associate!=null&&associate.getAssociateID()==associateId)
				 return associate;
		 }
		 return null;
		
	}
}
