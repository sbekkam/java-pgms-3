package com.cg.Payroll.daoservices;
import com.cg.Payroll.beans.Associate;
public class PayrollDAOServicesImp implements PayrollDAOServices{
	private static Associate[] associateList=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate){
		if(ASSOCIATE_IDX_COUNTER>=0.7*associateList.length) {
		Associate[] ass=new Associate[associateList.length+10];
		System.arraycopy(associateList, 0, ass, 0, associateList.length);
		associateList=ass;
	} 

		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++) 
			if (associateList[i]!=null && associate.getAssociateID()==associateList[i].getAssociateID()) {
				associateList[i]=associate;
				return true;
			}
		return false;
	}
	@Override
	public boolean deleteAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++)
			if (associateList[i]!=null && associate.getAssociateID()==associateList[i].getAssociateID()) {
				associateList[i]=null;
				return true;
			}
		return false;
	}
	@Override
	public Associate getAssociate(int associateId){
		for(Associate associate:associateList)
			//for(int i=0;i<associateList.length;i++) 
			if (associateList !=null && associateId==associate.getAssociateID()) 
				return associate;
		return null;
	}
	@Override
	public Associate[] getAssociates(){	
		return associateList;
	}
	@Override
	public int updateList() {
		for(int i=0;i<associateList.length;i++) 
			if (associateList[i]==null ) 
				for(int j=i+1;j<associateList.length;j++)
					if(associateList[j]!=null) {
						associateList[i]=associateList[j];
						associateList[j]=null;
						i++;
					}		
		for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null)
				ASSOCIATE_IDX_COUNTER++;

		
		return ASSOCIATE_IDX_COUNTER;
		
	}
	
}
