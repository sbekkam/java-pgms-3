package com.cg.Payroll.daoservices;

import com.cg.Payroll.beans.Associate;

public interface PayrollDAOServices {

	int insertAssociate(Associate associate);

	boolean updateAssociate(Associate associate);

	boolean deleteAssociate(Associate associate);

	Associate getAssociate(int associateId);

	Associate[] getAssociates();

	int updateList();

}