package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollServicesTest {

	private static PayrollServices payrollservices;
	private static PayrollDAOServices mockDaoServices;
	@BeforeClass
	public static void setUpTestEnv(){
		
		mockDaoServices=Mockito.mock(PayrollDAOServices.class);
		payrollservices= new PayrollServicesImpl();
	}
	//private int associateId;
	@Before 
	public  void setUpMockData(){
		Associate associate1 = new Associate(111, 15000, "sushma", "bekkam", "java", "analyst", "1234abcd", "abc.com", new Salary(50000, 1000, 1000), new BankDetails(12345678, "icici", "icic2001"));
		Associate associate2 = new Associate(112, 15000, "navya", "kudipudi", "java", "analyst", "1234abcd", "abc.com", new Salary(70000, 1000, 1000), new BankDetails(12345678, "icici", "icic2001"));

		ArrayList<Associate> associateList=new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		Mockito.when(mockDaoServices.getAssociate(111)).thenReturn(associate1);
		Mockito.when(mockDaoServices.getAssociate(112)).thenReturn(associate2);

	}
	@Test
	public void testValidAssociateDetails() throws  AssociateDetailsNotFoundException{
			payrollservices.getAssociateDetails(111);
			Mockito.verify(mockDaoServices).getAssociate(111);
	}

	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testInValidAssociateDetails() throws  AssociateDetailsNotFoundException
	{
		payrollservices.getAssociateDetails(123);
		Mockito.verify(mockDaoServices.getAssociate(123));

	}

	@Test 
	public void netsalary() throws AssociateDetailsNotFoundException,PayrollServicesDownException{
	
	}

	@After
	public  void tearDownMockData(){
		payrollservices.getAssociateDetails().clear();
		

	}
	@AfterClass
	public static void tearDownTestEnv(){
		payrollservices=null;



	}
}