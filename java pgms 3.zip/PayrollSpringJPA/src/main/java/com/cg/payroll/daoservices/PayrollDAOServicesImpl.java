package com.cg.payroll.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.PayrollServicesDownException;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {

	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;

	public PayrollDAOServicesImpl() throws PayrollServicesDownException {	

	}



	@Override
	public int insertAssociate(Associate associate) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate.getAssociateId();
	}


	@Override
	public boolean updateAssociate(Associate associate) {
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}


	@Override
	public boolean deleteAssociate(int associateId) {
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
				Associate associate= entityManager.find(Associate.class,associateId);
				entityManager.remove(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return false;
	}


	@Override
	public Associate getAssociate(int associateId) {
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		return entityManager.find(Associate.class, associateId);
	}


	@Override
	public List<Associate> getAssociates() {
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		TypedQuery<Associate> query = entityManager.createQuery("from Associate",Associate.class);
		return query.getResultList();
	}

	/*@Override
	public int insertAssociate(Associate associate) {
		Session session=  sessionFactory.openSession();
		Integer associateId =	(Integer) sessionFactory.openSession().save(associate);
		Transaction tx = session.beginTransaction();
		try {

			tx.commit();
			return associateId;

		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
			throw e;
		}
		finally {
			session.close();
		}

		//return (int) sessionFactory.openSession().save(associate);
	} 

	@Override
	public boolean updateAssociate(Associate associate)  {

		 sessionFactory.openSession().update(associate);
		return true;
	}



	@Override
	public boolean deleteAssociate(int associateId) {

		sessionFactory.openSession().delete(getAssociate(associateId));
		return false;
	}


	@Override
	public Associate getAssociate(int associateId) {

		return (Associate) sessionFactory.openSession().get(Associate.class, associateId);
	}


	@Override
	public List<Associate> getAssociates() {
		Session session = sessionFactory.openSession();
		Query query = (Query) session.createQuery("from Associate ");
		return query.list();
	}

	 */
}