package com.cg.RailwayReservation.beans;

public class Train {
	private String trainName;
	private int trainNo,pnrNo;
	public Train(String trainName, int trainNo, int pnrNo) {
		super();
		this.trainName = trainName;
		this.trainNo = trainNo;
		this.pnrNo = pnrNo;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public int getTrainNo() {
		return trainNo;
	}
	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}
	public int getPnrNo() {
		return pnrNo;
	}
	public void setPnrNo(int pnrNo) {
		this.pnrNo = pnrNo;
	}
	
}
