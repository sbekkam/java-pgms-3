package com.cg.RailwayReservation.beans;

public class Cancellation {
	private Float cancellationCharges,percentageOfCancellation;
	private String deadlineDate;
	private int amountRefunded;
	public Cancellation(Float cancellationCharges, Float percentageOfCancellation, String deadlineDate,
			int amountRefunded) {
		super();
		this.cancellationCharges = cancellationCharges;
		this.percentageOfCancellation = percentageOfCancellation;
		this.deadlineDate = deadlineDate;
		this.amountRefunded = amountRefunded;
	}
	public Float getCancellationCharges() {
		return cancellationCharges;
	}
	public void setCancellationCharges(Float cancellationCharges) {
		this.cancellationCharges = cancellationCharges;
	}
	public Float getPercentageOfCancellation() {
		return percentageOfCancellation;
	}
	public void setPercentageOfCancellation(Float percentageOfCancellation) {
		this.percentageOfCancellation = percentageOfCancellation;
	}
	public String getDeadlineDate() {
		return deadlineDate;
	}
	public void setDeadlineDate(String deadlineDate) {
		this.deadlineDate = deadlineDate;
	}
	public int getAmountRefunded() {
		return amountRefunded;
	}
	public void setAmountRefunded(int amountRefunded) {
		this.amountRefunded = amountRefunded;
	}
	
	 

}
